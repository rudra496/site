function [iteration, rootValue, err] = newton_raphson(func, dfunc, x0, err_limit, max_iter)
    iter = 1;
    iteration(1) = 0;
    rootValue(1) = x0;
    err(1) = 100;

    % Newton-Raphson 
    x = x0;
    while err(iter) > err_limit && iter < max_iter
        % function and derivative
        fx = func(x);
        dfx = dfunc(x);
        
        % Avoid division by zero
        if dfx == 0
            error('Derivative is zero. Cannot continue Newton-Raphson method.');
        end

        % root approximation Newton's method
        x_new = x - fx / dfx;

        % Store the current values
        iter = iter + 1;
        rootValue(iter) = x_new;
        iteration(iter) = iter - 1;
        err(iter) = abs(x_new - x) / x_new * 100;

        % Update for next iteration
        x = x_new;
    end
end


