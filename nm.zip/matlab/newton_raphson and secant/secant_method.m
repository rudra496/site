function [iteration, XL, XU, rootValue, err] = secant_method(func, x0, x1, err_limit, max_iter)
    iter = 1;
    iteration(1) = 0;
    rootValue(1) = 0;
    err(1) = 100;
    XL(1) = x0;
    XU(1) = x1;

    % Secant method
    while err(iter) > err_limit && iter < max_iter
        %  function at current points
        f0 = func(x0);
        f1 = func(x1);
        
        % Avoid division by zero
        if (f1 - f0) == 0
            error('Difference in function values is zero. Cannot continue Secant method.');
        end

        % root approximation secant method
        x_new = x1 - f1 * (x1 - x0) / (f1 - f0);

        % Store current value
        iter = iter + 1;
        rootValue(iter) = x_new;
        iteration(iter) = iter - 1;
        err(iter) = abs(x_new - x1) / x_new * 100;
        XL(iter) = x0;
        XU(iter) = x1;

        % Update for the next iteration
        x0 = x1;
        x1 = x_new;
    end
end
