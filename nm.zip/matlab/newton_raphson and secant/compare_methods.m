func = @(x) exp(-x) - x;
dfunc = @(x) -exp(-x) - 1;

% parameters
true_root = 0.56714329;
err_limit = 0.0001; 
max_iter = 10;

% Newton-Raphson method
x0_newton = 0.5; % Initial
[iter_n, root_n, err_n] = newton_raphson(func, dfunc, x0_newton, err_limit, max_iter);

% Secant method
x0_secant = 0.5;
x1_secant = 0.6;
[iter_s, XL_s, XU_s, root_s, err_s] = secant_method(func, x0_secant, x1_secant, err_limit, max_iter);

%  true errors
true_err_n = abs(root_n - true_root) / true_root * 100;
true_err_s = abs(root_s - true_root) / true_root * 100;

% Display results
fprintf('Newton-Raphson Method:\n');
fprintf('Iteration\tRoot\t\tTrue Error(%%)\n');
for i = 1:length(iter_n)
    fprintf('%d\t\t%.8f\t%.8f\n', iter_n(i), root_n(i), true_err_n(i));
end

fprintf('\nSecant Method:\n');
fprintf('Iteration\tRoot\t\tTrue Error(%%)\n');
for i = 1:length(iter_s)
    fprintf('%d\t\t%.8f\t%.8f\n', iter_s(i), root_s(i), true_err_s(i));
end

% Plot results
figure;

% Newton-Raphson convergence
subplot(2, 1, 1);
semilogy(iter_n, true_err_n, 'b-o', 'LineWidth', 2);
xlabel('Iteration');
ylabel('True Percent Relative Error (%)');
title('Newton-Raphson Method Convergence');
grid on;

% Secant method convergence
subplot(2, 1, 2);
semilogy(iter_s, true_err_s, 'r-*', 'LineWidth', 2);
xlabel('Iteration');
ylabel('True Percent Relative Error (%)');
title('Secant Method Convergence');
grid on;

% Display results
fprintf('\nFinal Results:\n');
fprintf('Method\t\tFinal Root\tTrue Error(%%)\tIterations\n');
fprintf('Newton-Raphson\t%.8f\t%.8f\t%d\n', root_n(end), true_err_n(end), length(iter_n)-1);
fprintf('Secant\t\t%.8f\t%.8f\t%d\n', root_s(end), true_err_s(end), length(iter_s)-1);
