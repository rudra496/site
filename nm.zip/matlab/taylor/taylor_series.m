function [taylor_approx] = taylor_series(func, degree, point, x)
    taylor_approx = 0;

    % Iterate  in Taylor series
    for n = 0:degree

        nth_derivative = diff(func, n);

        nth_derivative_value = double(subs(nth_derivative, point));

        %   Taylor series nth
        nth_term = (nth_derivative_value / factorial(n)) * (x - point)^n;

        %   Taylor series approximation nth
        taylor_approx = taylor_approx + nth_term;
    end
end
