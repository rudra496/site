syms x;
func = sin(x);
degree = 3;
point = 0; % h=(x-a)

taylor_approx = taylor_series(func, degree, point, x);

% original vs Taylor approximation
figure;
hold on;
fplot(func, [-pi, pi], 'LineWidth', 2);
fplot(taylor_approx, [-pi, pi], '--r', 'LineWidth', 1.5);
legend('Original Function', 'Taylor Series Approximation');
xlabel('x');
ylabel('y');
title('Taylor Series Approximation of sin(x)');

grid on;
zoom on;
hold off;
