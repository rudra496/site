syms x;
figure;
hold on;
fplot(sin(x), [-pi, pi], 'LineWidth', 2);

% 6th
taylor_6 = taylor(sin(x), x, 'Order', 7);
fplot(taylor_6, [-pi, pi], '--', 'LineWidth', 1.5);

% 8th
taylor_8 = taylor(sin(x), x, 'Order', 9);
fplot(taylor_8, [-pi, pi], '--', 'LineWidth', 1.5);

% 10th
taylor_10 = taylor(sin(x), x, 'Order', 11);
fplot(taylor_10, [-pi, pi], '--', 'LineWidth', 1.5);

legend('sin(x)', '6th Order', '8th Order', '10th Order');
xlabel('x');
ylabel('y');
title('Taylor Series Approximations of sin(x)');
grid on;
hold off;

% 2. cos(x)  8th
figure;
hold on;
fplot(cos(x), [-pi, pi], 'LineWidth', 2);
taylor_cos = taylor(cos(x), x, 'Order', 9);
fplot(taylor_cos, [-pi, pi], '--r', 'LineWidth', 1.5);
legend('cos(x)', '8th Order Approximation');
xlabel('x');
ylabel('y');
title('Taylor Series Approximation of cos(x)');
grid on;
hold off;

% 3. 1/(1+x)  10th
figure;
hold on;
fplot(1/(1+x), [-0.5, 2], 'LineWidth', 2);
taylor_frac = taylor(1/(1+x), x, 'Order', 11);
fplot(taylor_frac, [-0.5, 2], '--r', 'LineWidth', 1.5);
legend('1/(1+x)', '10th Order Approximation');
xlabel('x');
ylabel('y');
title('Taylor Series Approximation of 1/(1+x)');
grid on;
hold off;
