syms x;
f_a = 1/x;
a = -1;
taylor_a = taylor(f_a, x, a, 'Order', 4);
disp('Taylor series for 1/x about a = -1:');
disp(taylor_a);



f_b = -0.1*x^4 - 0.15*x^3 - 0.5*x^2 - 0.25*x + 1.2;
a_b = 0;
taylor_b = taylor(f_b, x, a_b, 'Order', 4);
disp('Taylor series for polynomial about a = 0:');
disp(taylor_b);



value_at_1 = double(subs(taylor_b, x, 1));
disp('Value at x = 1:');
disp(value_at_1);
