function [X, L, U, P] = lu_decomposition_solve(A, B)
    % A
    [row, column] = size(A);
    n = row;
    
    %  U, L, and P
    U = A;
    L = eye(n);
    P = eye(n);
    
    
    p = (1:n)';
    
    %  Matrix A for Pivot before U and L matrix
    for j = 1:column-1
        % row
        [~, max_row] = max(abs(U(j:n, j)));
        max_row = max_row + j - 1;
        
        if j ~= max_row
            % Swap rows in U
            temp = U(j,:);
            U(j,:) = U(max_row,:);
            U(max_row,:) = temp;
            
            % Swap rows in L
            if j > 1
                temp = L(j, 1:j-1);
                L(j, 1:j-1) = L(max_row, 1:j-1);
                L(max_row, 1:j-1) = temp;
            end
            
            % Swap rows in P
            temp = P(j,:);
            P(j,:) = P(max_row,:);
            P(max_row,:) = temp;
            
            % Swap rows in permutation vector
            temp = p(j);
            p(j) = p(max_row);
            p(max_row) = temp;
            
            % Swap rows in B
            temp = B(j);
            B(j) = B(max_row);
            B(max_row) = temp;
        end
        
        % Compute the multipliers and update U and L
        for i = j+1:row
            factor = U(i, j) / U(j, j);
            L(i, j) = factor;
            U(i, j:column) = U(i, j:column) - factor * U(j, j:column);
        end
    end
    
    % Forward substitution: L * Y = P * B
    Y = zeros(n, 1);
    for i = 1:n
        Y(i) = B(i) - L(i, 1:i-1) * Y(1:i-1);
    end
    
    % Backward substitution: U * X = Y
    X = zeros(n, 1);
    for i = n:-1:1
        X(i) = (Y(i) - U(i, i+1:n) * X(i+1:n)) / U(i, i);
    end
end

