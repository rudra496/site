Q01 = 100; Q13 = 50; Q31 = 30;
Q12 = 40; Q21 = 20; Q23 = 60; Q32 = 25;
c01 = 10; 


A = [Q01+Q31, 0, -Q13;
     -Q21, Q12+Q32, -Q23;
     -Q31, -Q32, Q13+Q23];
B = [Q01*c01; 0; 0];

% LU decomposition
[c, L, U, P] = lu_decomposition_solve(A, B);

fprintf('Reactor concentrations:\n');
fprintf('c1 = %.2f mg/m^3\n', c(1));
fprintf('c2 = %.2f mg/m^3\n', c(2));
fprintf('c3 = %.2f mg/m^3\n', c(3));

