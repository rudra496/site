A = [15, -3, -1;
     -3, 18, -6;
     -4, -1, 12];
B = [3800; 1200; 2350];

% LU decomposition
[c, L, U, P] = lu_decomposition_solve(A, B);

fprintf('Original problem:\n');
fprintf('c1 = %.2f g/m^3\n', c(1));
fprintf('c2 = %.2f g/m^3\n', c(2));
fprintf('c3 = %.2f g/m^3\n', c(3));

% Reduced mass input
B_new = [3800-500; 1200-250; 2350];

[c_new, ~, ~, ~] = lu_decomposition_solve(A, B_new);

fprintf('\nWith reduced mass input:\n');
fprintf('c1 = %.2f g/m^3\n', c_new(1));
fprintf('c2 = %.2f g/m^3\n', c_new(2));
fprintf('c3 = %.2f g/m^3\n', c_new(3));

fprintf('\nReduction in c3: %.2f g/m^3\n', c(3) - c_new(3));

