fprintf('Parachutist problem:\n');
A1 = [70, 1, 0; 60, -1, 1; 40, 0, -1];
B1 = [636.7; 518.6; 307.4];
[x1, L1, U1, P1] = lu_decomposition_solve(A1, B1);
disp('Solution:');
disp(x1);

% Truss problem
fprintf('\nTruss problem:\n');
A2 = [0.866, 0, -0.5, 0, 0, 0;
      0.5, 0, 0.866, 0, 0, 0;
      0, 1, 0.5, 0, 0, 0;
      -0.866, -1, 0, -1, 0, 0;
      -0.5, 0, 0, 0, -1, 0;
      0, 0, -0.866, 0, 0, -1];
B2 = [0; -1000; 0; 0; 0; 0];
[x2, L2, U2, P2] = lu_decomposition_solve(A2, B2);
disp('Solution:');
disp(x2);

% Circuit problem
fprintf('\nCircuit problem:\n');
A3 = [1, 1, 1, 0, 0, 0;
      0, -1, 0, 1, -1, 0;
      0, 0, -1, 0, 0, 1;
      0, 0, 0, 0, 1, -1;
      0, 10, -10, 0, -15, -5;
      5, -10, 0, -20, 0, 0];
B3 = [0; 0; 0; 0; 200; 0];
[x3, L3, U3, P3] = lu_decomposition_solve(A3, B3);
disp('Solution:');
disp(x3);

