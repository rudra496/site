clc;
clear all;

% parameters
g = 9.81;
z0 = 100;
v0 = 55;
m = 80;
c = 15;

% altitude function
altitude = @(t) z0 + (m/c)*(v0 + m*g/c)*(1 - exp(-(c/m)*t)) - (m*g/c)*t;

% time bounds
tL = 0;
tU = 10; 
err_limit = 1;
max_iter = 50;

% Run golden-section search
[t_opt, altitude_opt, history] = golden_section_search(altitude, tL, tU, err_limit, max_iter);

% Display results
fprintf('\nProjectile Altitude Optimization:\n');
fprintf('Optimal time for maximum altitude: %.4f s\n', t_opt);
fprintf('Maximum altitude: %.4f m\n', altitude_opt);

% Plot altitude curve
t_vals = linspace(0, 10, 1000);
altitude_vals = altitude(t_vals);
figure;
plot(t_vals, altitude_vals, 'b-', 'LineWidth', 2);
hold on;
plot(t_opt, altitude_opt, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
xlabel('Time (s)');
ylabel('Altitude (m)');
title('Projectile Altitude');
grid on;

