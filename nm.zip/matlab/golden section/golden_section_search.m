function [x_opt, f_opt, history] = golden_section_search(func, xL, xU, err_limit, max_iter)
    % Golden-section search
    R = (sqrt(5)-1)/2;
    d = R * (xU - xL);
    x1 = xL + d;
    x2 = xU - d;
    
    fxL = func(xL);
    fxU = func(xU);
    fx1 = func(x1);
    fx2 = func(x2);
    
    % Initialize history
    history.iteration = 0;
    history.xL = xL;
    history.xU = xU;
    history.x1 = x1;
    history.x2 = x2;
    history.fx1 = fx1;
    history.fx2 = fx2;
    history.error = inf;
    
    count = 0;
    error = inf;
    x_opt = xL;
    f_opt = fxL;
    
    fprintf('\n%-3s %-7s %-7s %-7s %-7s %-7s %-7s %-7s %-7s %-7s %-7s\n', ...
            'i', 'xL', 'f(xL)', 'x2', 'f(x2)', 'x1', 'f(x1)', 'xU', 'f(xU)', 'd', 'error');
    
    while error > err_limit && count < max_iter
        fprintf('%-3d %-7.4f %-7.4f %-7.4f %-7.4f %-7.4f %-7.4f %-7.4f %-7.4f %-7.4f %-7.4f\n', ...
                count, xL, fxL, x2, fx2, x1, fx1, xU, fxU, d, error);
        
        % Update the interval
        if fx1 > fx2
            % Maximum is in [x2, xU]
            x_opt = x1;
            f_opt = fx1;
            xL = x2;
            fxL = fx2;
            x2 = x1;
            fx2 = fx1;
            d = R * (xU - xL);
            x1 = xL + d;
            fx1 = func(x1);
        elseif fx1 < fx2
            % Maximum is in [xL, x1]
            x_opt = x2;
            f_opt = fx2;
            xU = x1;
            fxU = fx1;
            x1 = x2;
            fx1 = fx2;
            d = R * (xU - xL);
            x2 = xU - d;
            fx2 = func(x2);
        else
            % Maximum is at the midpoint
            xL = (x1 + x2)/2;
            xU = xL;
            x_opt = xL;
            f_opt = func(xL);
            break;
        end
        
        count = count + 1;
        error = (1 - R) * abs((xU - xL)/x_opt) * 100;
        
        % Store history
        history.iteration(count) = count;
        history.xL(count) = xL;
        history.xU(count) = xU;
        history.x1(count) = x1;
        history.x2(count) = x2;
        history.fx1(count) = fx1;
        history.fx2(count) = fx2;
        history.error(count) = error;
    end
    
    % Plot the function and optimum point
    x_vals = linspace(history.xL(1), history.xU(1), 1000);
    plot(x_vals, func(x_vals), 'b-', 'LineWidth', 2);
    hold on;
    plot(x_opt, f_opt, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    xlabel('x');
    ylabel('f(x)');
    title('Golden-Section Search Optimization');
    grid on;
    hold off;
end

