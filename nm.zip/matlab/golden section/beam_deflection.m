clc;
clear all;

% parameters
L = 600;
E = 50000;
I = 30000;
w0 = 2.5;

% deflection function
deflection = @(x) w0/(120*E*I*L) * (-x.^5 + 2*L^2*x.^3 - L^4*x);

xL = 0;
xU = L;
err_limit = 1;
max_iter = 50;

% Run golden-section search
[x_opt, deflection_opt, history] = golden_section_search(deflection, xL, xU, err_limit, max_iter);

% Display results
fprintf('\nBeam Deflection Optimization:\n');
fprintf('Optimal x for maximum deflection: %.2f cm\n', x_opt);
fprintf('Maximum deflection: %.6f cm\n', deflection_opt);

% Plot deflection curve
x_vals = linspace(0, L, 1000);
deflection_vals = deflection(x_vals);
figure;
plot(x_vals, deflection_vals, 'b-', 'LineWidth', 2);
hold on;
plot(x_opt, deflection_opt, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
xlabel('Distance along beam (cm)');
ylabel('Deflection (cm)');
title('Beam Deflection');
grid on;

