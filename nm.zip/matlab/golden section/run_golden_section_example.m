clc;
clear all;

% function
func = @(x) 2*sin(x) - x.^2/10;

% parameters
xL = 0;
xU = 4;
err_limit = 0.000002;
max_iter = 50;

% Run golden-section search
[x_opt, f_opt, history] = golden_section_search(func, xL, xU, err_limit, max_iter);

% Display results
fprintf('\nOptimal x: %.6f\n', x_opt);
fprintf('Optimal f(x): %.6f\n', f_opt);
