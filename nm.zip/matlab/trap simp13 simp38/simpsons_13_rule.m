function [I_approx, I_exact, rel_error] = simpsons_13_rule(f, a, b, n_values)
    I_approx = zeros(size(n_values));
    I_exact = zeros(size(n_values));
    rel_error = zeros(size(n_values));
    
    syms x_sym;
    I_exact_val = double(int(f(x_sym), a, b));
    
    for i = 1:length(n_values)
        n = n_values(i);
        
        % Simpson's 1/3 rule requires even number
        if mod(n, 2) ~= 0
            error('Simpson''s 1/3 rule requires an even number of subintervals.');
        end
        
        h = (b - a) / n;
        
        x = linspace(a, b, n+1);
        y = f(x);
        
        % Simpson's 1/3 rule
        I_approx(i) = h/3 * (y(1) + 4*sum(y(2:2:n)) + 2*sum(y(3:2:n-1)) + y(n+1));
        
        % Compute the relative error
        rel_error(i) = abs(I_exact_val - I_approx(i)) / abs(I_exact_val) * 100;
    end
    
    I_exact(:) = I_exact_val;
end
