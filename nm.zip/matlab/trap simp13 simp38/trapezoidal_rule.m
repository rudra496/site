function [I_approx, I_exact, true_error] = trapezoidal_rule(f, a, b, n_values)
    I_approx = zeros(size(n_values));
    I_exact = zeros(size(n_values));
    true_error = zeros(size(n_values));
    
    syms x_sym;
    I_exact_val = double(int(f(x_sym), a, b));
    
    for i = 1:length(n_values)
        n = n_values(i);
        
        h = (b - a) / n;
        
        x = linspace(a, b, n+1);
        y = f(x);
        
        % trapezoidal rule
        I_approx(i) = h/2 * (y(1) + 2*sum(y(2:n)) + y(n+1));
        
        % Compute the error
        true_error(i) = abs(I_exact_val - I_approx(i)) / abs(I_exact_val) * 100;
    end
    
    I_exact(:) = I_exact_val;
end


