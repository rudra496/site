clc;
clear all;

f = @(x) 0.2 + 25*x - 200*x.^2 + 675*x.^3 - 900*x.^4 + 400*x.^5;

a = 0;
b = 0.8;

n_values = 1:10;

%% Trapezoidal Rule
fprintf('=== Trapezoidal Rule ===\n');
[I_trap, I_exact_trap, error_trap] = trapezoidal_rule(f, a, b, n_values);

fprintf('n\tApproximate\tExact\t\tError (%%)\n');
for i = 1:length(n_values)
    fprintf('%d\t%.6f\t%.6f\t%.6f\n', n_values(i), I_trap(i), I_exact_trap(i), error_trap(i));
end

%% Simpson's 1/3 Rule
fprintf('\n=== Simpson''s 1/3 Rule ===\n');
% even values of n for Simpson's 1/3 rule
n_values_simp13 = n_values(mod(n_values, 2) == 0);
[I_simp13, I_exact_simp13, error_simp13] = simpsons_13_rule(f, a, b, n_values_simp13);

fprintf('n\tApproximate\tExact\t\tError (%%)\n');
for i = 1:length(n_values_simp13)
    fprintf('%d\t%.6f\t%.6f\t%.6f\n', n_values_simp13(i), I_simp13(i), I_exact_simp13(i), error_simp13(i));
end

%% Simpson's 3/8 Rule
fprintf('\n=== Simpson''s 3/8 Rule ===\n');
% multiples of 3 for Simpson's 3/8 rule
n_values_simp38 = [3, 6, 9];
[I_simp38, I_exact_simp38, error_simp38] = simpsons_38_rule(f, a, b, n_values_simp38);

fprintf('n\tApproximate\tExact\t\tError (%%)\n');
for i = 1:length(n_values_simp38)
    fprintf('%d\t%.6f\t%.6f\t%.6f\n', n_values_simp38(i), I_simp38(i), I_exact_simp38(i), error_simp38(i));
end

%% Plot the function
figure;
x_vals = linspace(a, b, 1000);
y_vals = f(x_vals);
plot(x_vals, y_vals, 'b-', 'LineWidth', 2);
xlabel('x');
ylabel('f(x)');
title('Function: f(x) = 0.2 + 25x - 200x^2 + 675x^3 - 900x^4 + 400x^5');
grid on;

%% Compare methods
figure;
semilogy(n_values, error_trap, 'b-o', 'LineWidth', 2);
hold on;
semilogy(n_values_simp13, error_simp13, 'r-*', 'LineWidth', 2);
semilogy(n_values_simp38, error_simp38, 'g-s', 'LineWidth', 2);
xlabel('Number of subintervals (n)');
ylabel('Relative Error (%)');
title('Comparison of Integration Methods');
legend('Trapezoidal Rule', 'Simpson''s 1/3 Rule', 'Simpson''s 3/8 Rule');
grid on;
