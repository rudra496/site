function [I_approx, I_exact, true_error] = simpsons_38_rule(f, a, b, n_values)
    I_approx = zeros(size(n_values));
    I_exact = zeros(size(n_values));
    true_error = zeros(size(n_values));
    
    % symbolic math
    syms x_sym;
    I_exact_val = double(int(f(x_sym), a, b));
    
    for i = 1:length(n_values)
        n = n_values(i);
        
        % Simpson's 3/8 rule requires multiple of 3 subintervals
        if mod(n, 3) ~= 0
            error('Simpson''s 3/8 rule requires a multiple of 3 subintervals.');
        end
        
        h = (b - a) / n;
        
        x = linspace(a, b, n+1);
        y = f(x);
        
        % Simpson's 3/8 rule
        I_approx(i) = 3*h/8 * (y(1) + 3*sum(y(2:3:n-1) + y(3:3:n)) + 2*sum(y(4:3:n-2)) + y(n+1));
        
        % Compute the error
        true_error(i) = abs(I_exact_val - I_approx(i)) / abs(I_exact_val) * 100;
    end
    
    I_exact(:) = I_exact_val;
end

