function [X, Y] = heun_method(dydx, x0, y0, h, n)
    % Heun's 
    X = zeros(n+1, 1);
    Y = zeros(n+1, 1);
    
    X(1) = x0;
    Y(1) = y0;
    
    % Heun's method
    for i = 1:n
        
        y1 = Y(i) + h * dydx(X(i), Y(i));
        
        % Update X
        X(i+1) = X(i) + h;
        
        % Heun's method
        y_pred = Y(i) + h/2 * (dydx(X(i), Y(i)) + dydx(X(i+1), y1));
        
        % Update Y
        Y(i+1) = y_pred;
    end
end
