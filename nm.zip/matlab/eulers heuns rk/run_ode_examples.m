clc;
clear all;

%%  Euler's method with error analysis
fprintf('=== Euler''s Method Example ===\n');

f = @(x, y) -2 * x.^3 + 12 * x.^2 - 20 * x + 8.5;
exact_eqn = @(x) -0.5 * x.^4 + 4 * x.^3 - 10 * x.^2 + 8.5 * x + 1;
f1 = @(x, y, h) (-6 * x.^2 + 24 * x - 20) * (h^2/2);
f2 = @(x, y, h) (-12 * x + 24) * (h^3/6);
f3 = @(x, y, h) (-12) * (h^4/24);

x0 = 0;
y0 = 1;
h = 0.5;
N = 10;

% Run Euler's method
[x_euler, y_euler, exact, global_err, local_err] = euler_method(f, exact_eqn, f1, f2, f3, x0, y0, h, N);

% Display results
fprintf('x\t\tEuler\t\tExact\t\tGlobal Error\tLocal Error\n');
for i = 1:length(x_euler)
    fprintf('%.3f\t%.3f\t\t%.3f\t\t%.3f\t\t%.3f\n', ...
            x_euler(i), y_euler(i), exact(i), global_err(i), local_err(i));
end

% Plot results
figure;
subplot(2,1,1);
plot(x_euler, y_euler, 'b-o', x_euler, exact, 'r--');
xlabel('x');
ylabel('y');
title('Euler''s Method vs Exact Solution');
legend('Euler', 'Exact');
grid on;

subplot(2,1,2);
plot(x_euler, global_err, 'b-o', x_euler, local_err, 'r--');
xlabel('x');
ylabel('Error (%)');
title('Error Analysis');
legend('Global Error', 'Local Error');
grid on;

%% Runge-Kutta 4th Order
fprintf('\n=== Runge-Kutta 4th Order Example ===\n');

% Run RK4 method
[x_rk4, y_rk4] = runge_kutta4(f, x0, y0, h, N);

% Display results
fprintf('x\t\tRK4\t\tExact\n');
for i = 1:length(x_rk4)
    fprintf('%.3f\t%.3f\t\t%.3f\n', x_rk4(i), y_rk4(i), exact(i));
end

% Plot results
figure;
plot(x_rk4, y_rk4, 'b-o', x_rk4, exact, 'r--');
xlabel('x');
ylabel('y');
title('Runge-Kutta 4th Order vs Exact Solution');
legend('RK4', 'Exact');
grid on;

%% Heun's Method
fprintf('\n=== Heun''s Method Example ===\n');

% Define the ODE
dydx = @(x, y) 4*exp(0.8*x) - 0.5*y;

x0 = 0;
y0 = 2;
h = 1;
n = 5;

% Run Heun's method
[X_heun, Y_heun] = heun_method(dydx, x0, y0, h, n);

% Display results
fprintf('x\t\tHeun\n');
for i = 1:length(X_heun)
    fprintf('%.3f\t%.3f\n', X_heun(i), Y_heun(i));
end

% Plot results
figure;
plot(X_heun, Y_heun, 'b-o');
xlabel('x');
ylabel('y');
title('Heun''s Method Solution');
grid on;
