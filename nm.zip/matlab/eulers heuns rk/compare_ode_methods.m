clc;
clear all;

f = @(x, y) -2 * x.^3 + 12 * x.^2 - 20 * x + 8.5;
exact_eqn = @(x) -0.5 * x.^4 + 4 * x.^3 - 10 * x.^2 + 8.5 * x + 1;

x0 = 0;
y0 = 1;
h = 0.5;
N = 10;

% all methods
[x_euler, y_euler] = euler_method(f, exact_eqn, @(x,y,h)0, @(x,y,h)0, @(x,y,h)0, x0, y0, h, N);
[x_rk4, y_rk4] = runge_kutta4(f, x0, y0, h, N);
exact = exact_eqn(x_euler);

% Calculate errors
error_euler = abs(y_euler - exact);
error_rk4 = abs(y_rk4 - exact);

% Display comparison
fprintf('Comparison of ODE Methods\n');
fprintf('x\t\tEuler\t\tRK4\t\tExact\t\tEuler Error\tRK4 Error\n');
for i = 1:length(x_euler)
    fprintf('%.3f\t%.3f\t\t%.3f\t\t%.3f\t\t%.3f\t\t%.3f\n', ...
            x_euler(i), y_euler(i), y_rk4(i), exact(i), error_euler(i), error_rk4(i));
end

% Plot comparison
figure;
subplot(2,1,1);
plot(x_euler, y_euler, 'b-o', x_rk4, y_rk4, 'g-s', x_euler, exact, 'r--');
xlabel('x');
ylabel('y');
title('Comparison of ODE Methods');
legend('Euler', 'RK4', 'Exact');
grid on;

subplot(2,1,2);
semilogy(x_euler, error_euler, 'b-o', x_rk4, error_rk4, 'g-s');
xlabel('x');
ylabel('Error');
title('Error Comparison');
legend('Euler Error', 'RK4 Error');
grid on;
