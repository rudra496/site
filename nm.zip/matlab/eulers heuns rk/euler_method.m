function [x, y, exact_soln, global_error, local_error] = euler_method(f, exact_eqn, f1, f2, f3, x0, y0, h, N)
    
    x = zeros(1, N+1);
    y = zeros(1, N+1);
    exact_soln = zeros(1, N+1);
    global_error = zeros(1, N+1);
    local_error = zeros(1, N+1);
    
    x(1) = x0;
    y(1) = y0;
    exact_soln(1) = exact_eqn(x0);
    global_error(1) = 0;
    local_error(1) = 0;
    
    % Euler's method
    for i = 1:N
        x(i+1) = x(i) + h;
        y(i+1) = y(i) + h * f(x(i), y(i));
        
        exact_soln(i+1) = exact_eqn(x(i+1));
        global_error(i+1) = abs(exact_soln(i+1) - y(i+1)) / abs(exact_soln(i+1)) * 100;
        local_error(i+1) = abs(f1(x(i), y(i), h) + f2(x(i), y(i), h) + f3(x(i), y(i), h)) / abs(exact_soln(i+1)) * 100;
    end
end
