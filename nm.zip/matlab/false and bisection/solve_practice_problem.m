func = @(x) sin(10*x) + cos(3*x);

xl = 12;
xu = 16;
err_limit = 0.5;
max_iter = 100;

%  bisection method
[iteration, XL, XU, rootValue, err] = bisection_method(func, xl, xu, err_limit, max_iter);

% Display results
fprintf('Bisection Method Results for f(x) = sin(10x) + cos(3x)\n');
fprintf('Iteration\tXL\t\tXU\t\tRoot\t\tError(%%)\n');
for i = 1:length(iteration)
    fprintf('%d\t\t%.6f\t%.6f\t%.6f\t%.6f\n', ...
            iteration(i), XL(i), XU(i), rootValue(i), err(i));
end

% Plot roots
figure;
x = linspace(12, 16, 1000);
y = func(x);
plot(x, y, 'b-', 'LineWidth', 2);
hold on;
plot(rootValue(end), func(rootValue(end)), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
xlabel('x');
ylabel('f(x)');
title('Function: f(x) = sin(10x) + cos(3x)');
grid on;
legend('Function', 'Estimated Root');

% Plot error convergence
figure;
semilogy(iteration(2:end), err(2:end), 'b-o', 'LineWidth', 2);
xlabel('Iteration');
ylabel('Percent Relative Error (%)');
title('Error Convergence in Bisection Method');
grid on;

fprintf('\nFinal root approximation: %.6f\n', rootValue(end));
fprintf('Final error: %.6f%%\n', err(end));
fprintf('Function value at root: %.6f\n', func(rootValue(end)));
