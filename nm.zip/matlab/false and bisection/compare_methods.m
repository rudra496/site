func = @(x) sin(10*x) + cos(3*x);
xl = 12;
xu = 16;
err_limit = 0.5;
max_iter = 100;

% Run both methods
[iter_b, XL_b, XU_b, root_b, err_b] = bisection_method(func, xl, xu, err_limit, max_iter);
[iter_f, XL_f, XU_f, root_f, err_f] = false_position(func, xl, xu, err_limit, max_iter);

% error comparison
figure;
semilogy(iter_b(2:end), err_b(2:end), 'b-o', 'LineWidth', 2);
hold on;
semilogy(iter_f(2:end), err_f(2:end), 'r-*', 'LineWidth', 2);
xlabel('Iteration');
ylabel('Percent Relative Error (%)');
title('Error Comparison: Bisection vs False Position');
legend('Bisection', 'False Position');
grid on;

% Display results
fprintf('Method\t\tFinal Root\tIterations\tFinal Error\n');
fprintf('Bisection\t%.6f\t%d\t\t%.6f%%\n', root_b(end), length(iter_b)-1, err_b(end));
fprintf('False Position\t%.6f\t%d\t\t%.6f%%\n', root_f(end), length(iter_f)-1, err_f(end));

