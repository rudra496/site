func = @(x) sin(10*x) + cos(3*x);

xl = 12;
xu = 16;
err_limit = 0.5; 
max_iter = 100;

% Run false position
[iteration, XL, XU, rootValue, err] = false_position(func, xl, xu, err_limit, max_iter);

% Display results
fprintf('Iteration\tXL\t\tXU\t\tRoot\t\tError(%%)\n');
for i = 1:length(iteration)
    fprintf('%d\t\t%.6f\t%.6f\t%.6f\t%.6f\n', ...
            iteration(i), XL(i), XU(i), rootValue(i), err(i));
end

% Plot the errors
figure;
plot(iteration(2:end), err(2:end), 'r-o', 'LineWidth', 2);
xlabel('Iteration');
ylabel('Percent Relative Error');
title('Error vs. Iteration for False Position Method');
grid on;
