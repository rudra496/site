function [iteration, XL, XU, rootValue, err] = bisection_method(func, xl, xu, err_limit, max_iter)


if sign(func(xl)) == sign(func(xu))
        error('Function has the same sign at interval boundaries. Bisection method cannot proceed.');
    end

    iter = 1;
    iteration(1) = 0;
    rootValue(1) = 0;
    err(1) = 100;
    XL(1) = xl;
    XU(1) = xu;
    root = 0;

    % Bisection
    while err(iter) > err_limit && iter < max_iter
        % Midpoint interval
        c = (xl + xu) / 2;

        %  function at midpoint
        fc = func(c);

        if sign(func(xl)) * sign(fc) < 0
            xu = c;
        else
            xl = c;
        end

        %  error and iteration
        iter = iter + 1;
        rootValue(iter) = c;
        err(iter) = abs(c - root)/c * 100;
        iteration(iter) = iter - 1;
        XL(iter) = xl;
        XU(iter) = xu;
        %  root approximation
        root = c;
    end
end
