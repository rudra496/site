function [iteration, XL, XU, rootValue, err] = false_position(func, xl, xu, err_limit, max_iter)
    if sign(func(xl)) == sign(func(xu))
        error('Function has the same sign at interval boundaries. False position method cannot proceed.');
    end

    %  iteration and error
    iter = 1;
    iteration(1) = 0;
    rootValue(1) = 0;
    err(1) = 100;
    root = 0;
    XL(1) = xl;
    XU(1) = xu;

    % False position 
    while err(iter) > err_limit && iter < max_iter
        %  new estimate false position
        xr = xu - (func(xu) * (xl - xu)) / (func(xl) - func(xu));

        fr = func(xr);

        if sign(func(xl)) * sign(fr) < 0
            xu = xr;
        else
            xl = xr;
        end

        %  error and iteration
        iter = iter + 1;
        rootValue(iter) = xr;
        err(iter) = abs(xr - root)/xr * 100;
        iteration(iter) = iter - 1;
        XL(iter) = xl;
        XU(iter) = xu;

        %  root approximation
        root = xr;
    end
end
